# OneMinecraftLauncher.NET

A modern Minecraft Launcher with Fluent Design, also called _OneMCL_.

> This is a very early version, the UI may be changed in future updates

> Note: this is a very early version and some features may be unstable

## Features

*   **Launch minecraft in customize directory** Detach minecraft core files and your saves, mods, and texturepacks into different directory
*   **Minecraft download**
*   **Libraries and assets checking and auto download**
*   Other basic minecraft launcher features

## Planned Features

*   Live Tiles support
*   Launch minecraft with cortana
*   Launch minecraft with command-line
*   Forge downloads and automatic installation

## Project Structure

*   **KMCCC** _modified KMCCC, an open-source minecraft launcher helper (submodule)_
*   **OneLauncher.Core** _Basic launcher freamwork, share libraries and models between all versions of OneMCL_
*   **OneLauncher.UWP** _UWP version of OneMCL, provides Windows 10 enhanced feature_
*   **OneLauncher.UWPCore** _A .NET desktop application, the real launcher behind the UWP shell, use AppService to commuicate with UWP app (Desktop Bridge)_
*   **OneLauncher.WPF** _WPF version of OneMCL_

## Development Requirements

*   Visual Studio 2017
*   Windows 10 SDK 16299
*   .NET Freamwork 4
*   .NET Core 2.0

## Contributing

If you interested in Fluent Design and UWP, we'd love your help! Feel free to contribute some codes :)
